# Purificador de Agua

Proyecto de Física Fundamental · Colegio Las Américas. Página web estática (HTML, CSS y JavaScript puros) con un simulador interactivo del filtro.

> Aviso: el agua de la maqueta **no es potable**. El filtro solo reduce partículas visibles. El simulador es didáctico y no usa datos medidos.

## Estructura

```
purificador-agua/
├── index.html
├── css/style.css
├── js/script.js
├── assets/maqueta.jpg
├── assets/anexo.jpg
├── .nojekyll
└── README.md
```

## Cómo publicarla en GitHub Pages

1. Crea un repositorio nuevo llamado `purificador-agua` (público).
2. Sube **el contenido** de esta carpeta a la raíz del repositorio (`index.html` debe quedar en la raíz, no dentro de otra carpeta). Incluye `assets/` y `.nojekyll`.
3. En el repositorio: **Settings → Pages → Build and deployment**. En *Source* elige **Deploy from a branch**, rama `main`, carpeta `/ (root)` y guarda.
4. Espera 1–2 minutos. La página quedará en `https://TU-USUARIO.github.io/purificador-agua/`.

## Cómo verla en tu computadora

Abre `index.html` con doble clic, o usa un servidor local: `python -m http.server` y visita `http://localhost:8000`.
